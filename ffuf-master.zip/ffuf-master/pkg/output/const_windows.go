// +build windows

package output

const (
	TERMINAL_CLEAR_LINE = "\r\r"
	ANSI_CLEAR          = ""
	ANSI_RED            = ""
	ANSI_GREEN          = ""
	ANSI_BLUE           = ""
	ANSI_YELLOW         = ""
)
